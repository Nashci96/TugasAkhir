package com.okedroid.apktaichsan;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.okedroid.apktaichsan.Adapter.MahasiswaListAdapter;
import com.okedroid.apktaichsan.Model.MahasiswaListModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class DsnDataBimbinganMhs extends AppCompatActivity {

    TextView namaMhs, noBp, topikTa, deskripsi;
    String namaMhsStr, noBpStr, topikTaStr, deskripsiStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dsn_data_bimbingan_mhs);

        namaMhsStr = getIntent().getStringExtra("nama");
        noBpStr = getIntent().getStringExtra("noBp");
        topikTaStr = getIntent().getStringExtra("topikTA");
        deskripsiStr = getIntent().getStringExtra("deskripsi");

        namaMhs = findViewById(R.id.namaMhs);
        noBp = findViewById(R.id.noBpMhs);
        topikTa = findViewById(R.id.topikTA);
        deskripsi = findViewById(R.id.deskripsi);

        namaMhs.setText(namaMhsStr);
        noBp.setText(noBpStr);
        topikTa.setText(topikTaStr);
        deskripsi.setText(deskripsiStr);

    }
}
