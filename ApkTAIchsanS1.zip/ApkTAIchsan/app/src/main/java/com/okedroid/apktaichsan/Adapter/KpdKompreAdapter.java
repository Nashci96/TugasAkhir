package com.okedroid.apktaichsan.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.okedroid.apktaichsan.KpdListKompreAct;
import com.okedroid.apktaichsan.Model.KpdKompreModel;
import com.okedroid.apktaichsan.R;

import java.util.ArrayList;

public class KpdKompreAdapter extends RecyclerView.Adapter<KpdKompreAdapter.KpdKompreViewHolder> {

    ArrayList<KpdKompreModel> dataList;
    Context context;

    public KpdKompreAdapter(ArrayList<KpdKompreModel>dataList,Context context){
        this.dataList = dataList;
        this.context = context;
    }

    @NonNull
    @Override
    public KpdKompreAdapter.KpdKompreViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.item_kpd_kompre,viewGroup, false);
        return new KpdKompreAdapter.KpdKompreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KpdKompreAdapter.KpdKompreViewHolder kpdKompreViewHolder, final int i) {
        kpdKompreViewHolder.namaMhs.setText(dataList.get(i).GetNama());
        kpdKompreViewHolder.nobpMhs.setText(dataList.get(i).GetNobp());
        kpdKompreViewHolder.judulMhs.setText(dataList.get(i).GetJudul());

        kpdKompreViewHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, KpdListKompreAct.class);
                intent.putExtra("namaMhs",dataList.get(i).GetNama());
                intent.putExtra("noBp",dataList.get(i).GetNobp());
                intent.putExtra("judulTA",dataList.get(i).GetJudul());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (dataList!=null) ? dataList.size() : 0;
    }

    public class KpdKompreViewHolder extends RecyclerView.ViewHolder {

        TextView namaMhs , judulMhs , nobpMhs;
        CardView mainLayout;

        public KpdKompreViewHolder(@NonNull View itemView) {
            super(itemView);
            namaMhs = itemView.findViewById(R.id.namaMhsKpdKompre);
            judulMhs= itemView.findViewById(R.id.judulTAKpdKompre);
            nobpMhs = itemView.findViewById(R.id.nobpKpdKompre);
        }
    }
}
