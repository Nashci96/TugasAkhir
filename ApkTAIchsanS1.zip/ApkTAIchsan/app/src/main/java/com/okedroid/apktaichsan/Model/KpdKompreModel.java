package com.okedroid.apktaichsan.Model;

public class KpdKompreModel {

    String nama,nobp,judul,n_pbb_1,n_pbb_2,n_pgj_1,n_pgj_2,tgl,shift;

    public KpdKompreModel(String nama,String nobp,String judul,String nip_pbb_1,String nip_pbb_2,String n_pbb_1,String n_pbb_2,
                          String nip_pgj_1,String nip_pgj_2,String n_pgj_1,String n_pgj_2,String tgl,String shift){
        this.nama   = nama;
        this.nobp   = nobp;
        this.judul  = judul;
        this.n_pbb_1 = n_pbb_1;
        this.n_pbb_2 = n_pbb_2;
        this.n_pgj_1 = n_pgj_1;
        this.n_pgj_2 = n_pgj_2;
        this.tgl = tgl;
        this.shift = shift;
    }

    public String GetNama() { return  nama;}
    public String GetNobp() { return  nobp;}
    public String GetJudul() { return  judul;}
    public String GetNamaPbb1() {return  n_pbb_1;}
    public String GetNamaPbb2() {return  n_pbb_2;}
    public String GetNamaPgj1() {return  n_pgj_1;}
    public String GetNamaPgj2() {return  n_pgj_2;}
    public String GetTgl() {return  tgl;}
    public String GetShift() {return  shift;}

    public void setNama(String nama){ this.nama = nama;}
    public void setNobp(String nobp){ this.nama = nobp;}
    public void setJudul(String judul){ this.judul = judul;}
    public void setN_pbb_1(String n_pbb_1){this.n_pbb_1 = n_pbb_1;}
    public void setN_pbb_2(String n_pbb_2){this.n_pbb_2 = n_pbb_2;}
    public void setN_pgj_1(String n_pgj_1){this.n_pgj_1 = n_pgj_1;}
    public void setN_pgj_2(String n_pgj_2){this.n_pgj_2 = n_pgj_2;}
    public void setTgl(String tgl){this.tgl = tgl;}
    public void setShift(String shift){this.shift = shift;}

}
