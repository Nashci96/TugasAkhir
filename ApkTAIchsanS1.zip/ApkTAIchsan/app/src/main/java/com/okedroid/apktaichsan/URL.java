package com.okedroid.apktaichsan;

public class URL {
    public static final String AlokasiPgjSempro = "http://10.0.2.2/ta/kpd/alokasiPgjSempro.php";
    public static final String AlokasiPgjSemhas = "http://10.0.2.2/ta/kpd/alokasiPgjSemhas.php";
    public static final String AlokasiPgjKompre = "http://10.0.2.2/ta/kpd/alokasiPgjKompre.php";

    public static final String ListSemproBerlangsung = "http://10.0.2.2/ta/kpd/ListSempro.php";
    public static final String ListSemhasBerlangsung = "http://10.0.2.2/ta/kpd/ListSemhas.php";
    public static final String ListKompreBerlangsung = "http://10.0.2.2/ta/kpd/ListKompre.php";

}
