package com.okedroid.apktaichsan;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivityKpd extends AppCompatActivity {

    private String id,pass;
    private EditText etUseridkpd,etPasskpd;
    private Button bLoginKpd,bLoginOptKpd;
    private static String URL_LOGIN_KPD ="http://10.0.2.2/ta/kpd/login.php";
//    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_kpd);

        etUseridkpd = findViewById(R.id.et_useridkpd);
        etPasskpd   = findViewById(R.id.et_passkpd);
        bLoginKpd   = findViewById(R.id.buttonLoginKpd);
        bLoginOptKpd= findViewById(R.id.buttonLoginOptKpd);

        bLoginKpd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                id  = etUseridkpd.getText().toString().trim();
                pass     = etPasskpd.getText().toString().trim();

                if (!id.isEmpty() || !pass.isEmpty()){
                    Login(id,pass);
                } else {
                    etUseridkpd.setError("Please insert ID");
                    etPasskpd.setError("Please insert password");
                }
            }
        });

        bLoginOptKpd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( LoginActivityKpd.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void Login(final String id, final String pass) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN_KPD,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("login");

                            if (success.equals("1")) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject object = jsonArray.getJSONObject(i);
                                    String name = object.getString("name").trim();
                                    String id = object.getString("id").trim();
                                    String level = object.getString("level").trim();

                                    SharedPreferences pref = getSharedPreferences("user",MODE_PRIVATE);
                                    SharedPreferences.Editor editor = pref.edit();
                                    editor.putString("user",id);
                                    editor.putString("level", level);
                                    editor.putString("name",name);
                                    editor.apply();

                                    Intent intent = new Intent(LoginActivityKpd.this, KpdMainMenu.class);
                                    intent.putExtra("name", name);
                                    intent.putExtra("id", id);
                                    intent.putExtra("level", level);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(LoginActivityKpd.this, "Error" + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginActivityKpd.this,"Error"+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                }
        )
        {
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> params = new HashMap<>();
                params.put("id",id);
                params.put("pass",pass);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
}
