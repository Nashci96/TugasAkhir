package com.okedroid.apktaichsan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AdmRegSidang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adm_reg_sidang);
    }
}
